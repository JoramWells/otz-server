export class Patient{
    constructor(
        public id: string,
        public firstName: string,
        public middleName: string,
        public lastName: string,
        public gender: string,
        public dob: string,
        public phoneNo: string,
        public idNo: string,
        public nupi: string,
        public residence: string,
    ){}
}