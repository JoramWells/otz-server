export class ClassEntity {
  constructor(
    public id: string,
    public schoolSubCategoryID: string,
    public classDescription: string
  ) {}
}