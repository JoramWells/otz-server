export class SchoolCategory {
    constructor(
        public id: string,
        public schoolCategoryDescription: string
    ){}
}