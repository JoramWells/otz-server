export class SchoolSubCategory {
  constructor(
    public id: string,
    public schoolCategoryID: string,
    public schoolSubCategoryDescription: string
  ) {}
}